@extends('layouts.app')

@section('content')
<div class="vh-100">
  <div class="d-flex justify-content-center align-items-center flex-column vh-100">
    <i class="fas fa-times-circle text-danger fa-10x"></i>
    <h3 class="py-5">Fully Booked.</h3>
    <a class="btn btn-info" href="/">Go back</a>
  </div>
</div>
@endsection
