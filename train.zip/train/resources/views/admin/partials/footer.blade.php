<footer class="sticky-footer bg-white">
  <div class="container my-auto">
    <div class="copyright text-center my-auto">
      <span>Copyright &copy; {{ config('app.name') }} {{ date('Y') }}</span>
    </div>
  </div>
</footer>
