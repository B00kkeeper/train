@extends('layouts.app')

@section('content')
<div class="d-flex justify-content-center align-items-center flex-column vh-100">
  <i class="fas fa-check-circle text-success fa-10x"></i>
  <div class="d-flex flex-column justify-content-center align-items-center py-5">
    <h3>Booking Payment Transaction recorded.</h3>
  </div>
</div>
@endsection
