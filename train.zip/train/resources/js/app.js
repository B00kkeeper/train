require('./bootstrap');

require("datatables.net-bs4");

$(function () {
    $("#dataTable").DataTable();
});
