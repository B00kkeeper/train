<?php

namespace App\Http\Controllers;

use App\Station;
use Illuminate\Http\Request;

class StationController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $stations = Station::all();
        return view('admin.station.index', compact('stations'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
        ]);

        Station::create([
            'name' => $request->name,
        ]);

        return redirect()->back()->withSuccess('Station added.');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Station  $station
     * @return \Illuminate\Http\Response
     */
    public function show(Station $station)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Station  $station
     * @return \Illuminate\Http\Response
     */
    public function edit(Station $station)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Station  $station
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Station $station)
    {
        $request->validate([
            'name' => 'required|string|max:255',
        ]);

        $station = Station::find($station->id);

        $station->name = $request->name;

        $station->save();

        return redirect()->back()->withSuccess('Station name updated.');

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Station  $station
     * @return \Illuminate\Http\Response
     */
    public function destroy(Station $station)
    {
        $redirect = redirect()->back();

        try {
            $station->delete();
            $redirect->withSuccess('Station Deleted.');
        } catch (\Illuminate\Database\QueryException$e) {
            $redirect->withFail('Record has associated entries. Action aborted.');
        } catch (\Exception$e) {
            $redirect->withFail('Could not perform request');
        }

        return $redirect;

    }
}
